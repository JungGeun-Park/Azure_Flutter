#!/bin/sh
chmod +x ./ci_post_xcodebuild.rb
./ci_post_xcodebuild.rb
